How to upload this to GitHub Pages

1. Open your GitHub repo.
2. Delete the old site files if they are there.
3. Upload EVERY file from this folder directly to the repo root.
4. Make sure you can see index.html immediately on the repo Code page.
5. Go to Settings > Pages.
6. Under Source, choose Deploy from a branch.
7. Select main and /(root).
8. Save.
9. Wait about 1 minute and refresh the Pages section.

Important:
- index.html must be at the top level of the repo.
- Do not upload a parent folder around these files.
